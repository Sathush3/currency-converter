import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class CurrencyDropdown extends StatefulWidget {
  final Function(Map<String, dynamic>) onSelected;
  final List<Map<String, dynamic>> currencies;
  final Map<String, dynamic> initialValue;

  const CurrencyDropdown({
    super.key,
    required this.onSelected,
    required this.currencies,
    required this.initialValue,
  });

  @override
  State<CurrencyDropdown> createState() => _CurrencyDropdownState();
}

class _CurrencyDropdownState extends State<CurrencyDropdown> {
  Map<String, dynamic>? _selectedCurrency;

  @override
  void initState() {
    super.initState();

    _selectedCurrency = widget.currencies.firstWhere(
      (curr) => curr['currencyCode'] == widget.initialValue['currencyCode'],
    );
    log('Selected currency: $_selectedCurrency');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 22.w,
      color: const Color(0xFF262425).withOpacity(0.95),
      child: DropdownButton<Map<String, dynamic>>(
        underline: Container(),
        borderRadius: BorderRadius.circular(3.w),
        focusColor: const Color(0xFF262425).withOpacity(0.95),
        value: _selectedCurrency,
        items: widget.currencies.map((currency) {
          return DropdownMenuItem<Map<String, dynamic>>(
            value: currency,
            child: Row(
              children: [
                Image.asset(
                  currency['flagIcon'],
                  width: 16.sp,
                  height: 16.sp,
                ),
                SizedBox(
                  width: 2.w,
                ),
                Text(
                  currency['currencyCode'],
                  style: TextStyle(
                    fontSize: 16.sp,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
        onChanged: (value) {
          setState(() {
            _selectedCurrency = value;
          });
          widget.onSelected(value!);
        },
        dropdownColor: const Color(0xFF262425).withOpacity(0.95),
        style: TextStyle(
          color: Theme.of(context).textTheme.bodyLarge!.color,
          fontSize: 16.sp,
        ),
      ),
    );
  }
}
