import 'package:currency_converter/components/textfield/custom_textfield.dart';
import 'package:currency_converter/widgets/curreny_dropdown_widget/curreny_dropdown_widget.dart';
import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class CurrencyCardWidget extends StatefulWidget {
  final List<Map<String, dynamic>> currencies;
  final Map<String, dynamic> initialCurrency;
  final Function(String) onChanged;
  final Function onDelete;
  final Function(Map<String, dynamic>) onDropdownPressed;
  final String convertedValue;

  const CurrencyCardWidget({
    super.key,
    required this.currencies,
    required this.initialCurrency,
    required this.onChanged,
    required this.onDelete,
    required this.onDropdownPressed,
    required this.convertedValue,
  });

  @override
  State<CurrencyCardWidget> createState() => _CurrencyCardWidgetState();
}

class _CurrencyCardWidgetState extends State<CurrencyCardWidget> {
  final focusNode = FocusNode();
  final controller = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Card(
        color: const Color(0xFF262425).withOpacity(0.95),
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 3.w),
          child: Row(
            children: [
              Expanded(
                child: CustomTextField(
                  height: 3.h,
                  hintText: 'Enter amount',
                  controller: controller,
                  focusNode: focusNode,
                  keyboardType: TextInputType.number,
                  labelText: widget.convertedValue,
                  onChanged: (String value) {
                    widget.onChanged(value);
                  },
                  borderColor: Colors.transparent,
                ),
              ),
              CurrencyDropdown(
                onSelected: widget.onDropdownPressed,
                currencies: widget.currencies,
                initialValue: widget.initialCurrency,
              ),
           
            ],
          ),
        ),
      ),
    );
  }
}
