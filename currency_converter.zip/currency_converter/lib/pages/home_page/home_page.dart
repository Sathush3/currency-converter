import 'dart:developer';
import 'package:currency_converter/api/currency_service/http_currency_service.dart';
import 'package:currency_converter/components/button/add_converter_button.dart';
import 'package:currency_converter/components/snackbar/custom_snackbar.dart';
import 'package:currency_converter/model/currency_card_model/currency_card_model.dart';
import 'package:currency_converter/stores/currency_exchange_store/currency_store.dart';
import 'package:currency_converter/widgets/custom_card_widget/custom_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:get_it/get_it.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController inputController = TextEditingController();
  final _currencyApiService = GetIt.I<CurrencyApiService>();
  final _currencyStore = GetIt.I<CurrencyStore>();

  List<Map<String, dynamic>> currencies = [];
  bool isLoading = true;
  bool hasError = false;
  String baseCurrency = 'LKR';
  double baseAmount = 0.0;
  List<String> convertedValues = [];

  Future<void> _fetchCurrencies() async {
    try {
      final response = await _currencyApiService.getCurrencies();
      if (response.isEmpty) {
        throw Exception("No data available");
      }
      if (mounted) {
        setState(() {
          currencies = response.entries
              .map((entry) => {
                    'currencyCode': entry.key,
                    'currencyName': entry.value,
                    'flagIcon': 'assets/flags/${entry.key}.png',
                  })
              .toList();
          hasError = false;
        });
      }
    } on Exception catch (e) {
      log("Failed to load currencies: $e", name: 'HomePage');
      CustomSnackBar.floatToast(
        context: context,
        message:
            "Failed to load currencies. Please check your internet connection.",
      );
      if (mounted) {
        setState(() {
          hasError = true;
        });
      }
    }
  }

  Future<void> _initData() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }
    try {
      await _fetchCurrencies();
      await _currencyStore.initDatabase();
      await _currencyStore.loadCurrencyCards();
      if (mounted) {
        setState(() {
          hasError = false;
        });
      }
    } catch (e) {
      log("Failed to initialize data: $e", name: 'HomePage');
      CustomSnackBar.floatToast(
        context: context,
        message:
            "Failed to initialize data. Please check your internet connection.",
      );
      if (mounted) {
        setState(() {
          hasError = true;
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> _convertCurrencies() async {
    if (baseAmount > 0) {
      List<String> symbols = _currencyStore.currencyCards
          .map((card) => card.currencyCode)
          .toList();
      if (symbols.isNotEmpty) {
        try {
          final rates =
              await _currencyApiService.getExchangeRates(baseCurrency, symbols);
          if (mounted) {
            setState(() {
              convertedValues = symbols.map((symbol) {
                var rate = rates[symbol] ?? 0;
                return (baseAmount * rate).toStringAsFixed(2);
              }).toList();
            });
          }
        } catch (e) {
          log("Failed to convert currencies: $e", name: 'HomePage');
          CustomSnackBar.floatToast(
            context: context,
            message: "Failed to convert currencies. Please try again later.",
          );
        }
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff181818),
      appBar: AppBar(
        backgroundColor: const Color(0xff181818),
        centerTitle: true,
        title: Text(
          'Advanced Exchanger',
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w400,
          ),
        ),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: SafeArea(
          child: Stack(
            children: [
              if (!isLoading && !hasError)
                Observer(
                  builder: (_) => SingleChildScrollView(
                    child: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 4.w,
                        vertical: 4.h,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "INSERT AMOUNT:",
                            style: TextStyle(
                                fontSize: 15.sp,
                                color: const Color(0xff4d4d4d),
                                fontWeight: FontWeight.w600),
                          ),
                          CurrencyCardWidget(
                            initialCurrency: {
                              'currencyCode': baseCurrency,
                              'currencyName': 'United States Dollar',
                              'flagIcon': 'assets/flags/usd.png'
                            },
                            currencies: currencies,
                            onChanged: (value) {
                              baseAmount = double.tryParse(value) ?? 0;
                              _convertCurrencies();
                            },
                            onDropdownPressed: (currency) {
                              baseCurrency = currency['currencyCode'];
                              _convertCurrencies();
                            },
                            onDelete: () {},
                            convertedValue: '',
                          ),
                          SizedBox(
                            height: 4.h,
                          ),
                          Text(
                            "CONVERT TO:",
                            style: TextStyle(
                                fontSize: 15.sp,
                                color: const Color(0xff4d4d4d),
                                fontWeight: FontWeight.w600),
                          ),
                          ListView.builder(
                            shrinkWrap: true,
                            itemCount: _currencyStore.currencyCards.length,
                            itemBuilder: (context, index) {
                              final currency =
                                  _currencyStore.currencyCards[index];
                              return Dismissible(
                                key: Key(currency.id.toString()),
                                onDismissed: (direction) async {
                                  await _currencyStore
                                      .deleteCurrencyCard(currency.id);
                                },
                                confirmDismiss: (direction) async {
                                  return await showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: Text("Confirm"),
                                        content: Text(
                                            "Are you sure you want to delete this item?"),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.of(context)
                                                    .pop(false),
                                            child: Text("Cancel"),
                                          ),
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.of(context).pop(true),
                                            child: Text("Delete"),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                                child: CurrencyCardWidget(
                                  initialCurrency: {
                                    'currencyCode': currency.currencyCode,
                                    'currencyName': currency.currencyName,
                                    'flagIcon': currency.flagIcon,
                                  },
                                  currencies: currencies,
                                  onChanged: (value) {},
                                  onDropdownPressed: (selectedCurrency) {
                                    _currencyStore.currencyCards[index] =
                                        CurrencyCardModel(
                                      id: _currencyStore
                                          .currencyCards[index].id,
                                      currencyCode:
                                          selectedCurrency['currencyCode'],
                                      currencyName:
                                          selectedCurrency['currencyName'],
                                      flagIcon: selectedCurrency['flagIcon'],
                                    );
                                    _currencyStore.updateCurrencyCard(
                                        _currencyStore.currencyCards[index]);
                                    _convertCurrencies();
                                  },
                                  onDelete: () async {
                                    await _currencyStore
                                        .deleteCurrencyCard(currency.id);
                                    _convertCurrencies();
                                  },
                                  convertedValue: convertedValues.length > index
                                      ? convertedValues[index]
                                      : '',
                                ),
                              );
                            },
                          ),
                          Center(
                            child: AddConverterButton(onPressed: () async {
                              if (currencies.isEmpty) {
                                return;
                              }
                              final usdCurrency = currencies.firstWhere(
                                  (currency) =>
                                      currency['currencyCode'] == 'USD',
                                  orElse: () => currencies[0]);
                              final card = CurrencyCardModel(
                                id: 0,
                                currencyCode: usdCurrency['currencyCode'],
                                currencyName: usdCurrency['currencyName'],
                                flagIcon: usdCurrency['flagIcon'],
                              );
                              await _currencyStore.addCurrencyCard(card);
                              _convertCurrencies();
                            }),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              if (isLoading || hasError)
                Center(
                  child: Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (isLoading)
                          LoadingAnimationWidget.staggeredDotsWave(
                            color: Colors.white,
                            size: 6.h,
                          ),
                        if (hasError)
                          Column(
                            children: [
                              Text(
                                "An error occurred. Please try again.",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16.sp,
                                ),
                              ),
                              SizedBox(height: 2.h),
                              ElevatedButton(
                                onPressed: _initData,
                                child: Text(
                                  "Retry",
                                  style: TextStyle(fontSize: 16.sp),
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
