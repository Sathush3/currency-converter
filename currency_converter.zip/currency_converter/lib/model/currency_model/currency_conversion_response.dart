class CurrencyConversionResponse {
  final String date;
  final Info info;
  final Query query;
  final double result;
  final bool success;

  CurrencyConversionResponse({
    required this.date,
    required this.info,
    required this.query,
    required this.result,
    required this.success,
  });

  factory CurrencyConversionResponse.fromJson(Map<String, dynamic> json) {
    return CurrencyConversionResponse(
      date: json['date'],
      info: Info.fromJson(json['info']),
      query: Query.fromJson(json['query']),
      result: json['result'],
      success: json['success'],
    );
  }
}

class Info {
  final double rate;
  final int timestamp;

  Info({required this.rate, required this.timestamp});

  factory Info.fromJson(Map<String, dynamic> json) {
    return Info(
      rate: json['rate'],
      timestamp: json['timestamp'],
    );
  }
}

class Query {
  final int amount;
  final String from;
  final String to;

  Query({required this.amount, required this.from, required this.to});

  factory Query.fromJson(Map<String, dynamic> json) {
    return Query(
      amount: json['amount'],
      from: json['from'],
      to: json['to'],
    );
  }
}
