class CurrencyCardModel {
  final int id;
  final String currencyCode;
  final String currencyName;
  final String flagIcon;

  CurrencyCardModel({
    required this.id,
    required this.currencyCode,
    required this.currencyName,
    required this.flagIcon,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'currency_code': currencyCode,
      'currency_name': currencyName,
      'flag_icon': flagIcon,
    };
  }

  static CurrencyCardModel fromMap(Map<String, dynamic> map) {
    return CurrencyCardModel(
      id: map['id'],
      currencyCode: map['currency_code'],
      currencyName: map['currency_name'],
      flagIcon: map['flag_icon'],
    );
  }
}
