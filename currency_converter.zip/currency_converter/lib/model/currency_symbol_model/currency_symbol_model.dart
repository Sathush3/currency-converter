class CurrencySymbolsResponse {
  final bool success;
  final Map<String, String> symbols;

  CurrencySymbolsResponse({required this.success, required this.symbols});

  factory CurrencySymbolsResponse.fromJson(Map<String, dynamic> json) {
    return CurrencySymbolsResponse(
      success: json['success'],
      symbols: Map<String, String>.from(json['symbols']),
    );
  }
}
