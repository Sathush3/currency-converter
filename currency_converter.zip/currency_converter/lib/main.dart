import 'dart:async';

import 'package:currency_converter/routes/app_routes.dart';
import 'package:currency_converter/services/permission_services/permission_services.dart';
import 'package:currency_converter/themes/theme_config.dart';
import 'package:currency_converter/utils/get_it/get_it.dart';
import 'package:easy_dynamic_theme/easy_dynamic_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  await dotenv.load(fileName: '.env');
  WidgetsFlutterBinding.ensureInitialized();
  await getItInitialize();
  checkFirstRun();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(EasyDynamicThemeWidget(child: const MainApp()));
}

Future<void> checkFirstRun() async {
  final prefs = await SharedPreferences.getInstance();
  final permissionService = PermissionService();
  await permissionService.requestPermission(
    Permission.manageExternalStorage,
  );

  if (prefs.getBool('firstRun') ?? true) {
    // await sqlDatabaseService.deleteDatabase();

    prefs.setBool('firstRun', false);
  }
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ResponsiveSizer(
      builder: (context, orientation, deviceType) {
        return MaterialApp.router(
          title: 'Currency Converter',
          theme: AppThemes.lightTheme,
          darkTheme: AppThemes.darkTheme,
          themeMode: EasyDynamicTheme.of(context).themeMode,
          routerConfig: router,
        );
      },
    );
  }
}
