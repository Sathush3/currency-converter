import 'dart:developer';

import 'package:currency_converter/model/currency_symbol_model/currency_symbol_model.dart';
import 'package:currency_converter/services/base_api_service/base_api_service.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class CurrencyApiService extends BaseApiService {
  CurrencyApiService()
      : super(
          endPointUrl: '',
          baseUrl: dotenv.get('API_BASE_URL',
              fallback: 'https://api.apilayer.com/exchangerates_data'),
          customHeaders: {
            'apikey': dotenv.get('API_KEY'),
          },
        );

  Future<Map<String, dynamic>> getExchangeRates(
      String base, List<String> symbols) async {
    final queryParams = {
      'symbols': symbols.join(','),
      'base': base,
    };

    final response = await fetch(
      endpoint: 'exchangerates_data/latest',
      filterSortObject: queryParams,
    );

    if (response['success']) {
      return response['rates'];
    } else {
      throw Exception('Failed to load exchange rates');
    }
  }

  Future<double> convertCurrency(String from, String to, double amount) async {
    final queryParams = {
      'from': from,
      'to': to,
      'amount': amount.toString(),
    };

    final response = await fetch(
      endpoint: 'convert',
      filterSortObject: queryParams,
    );

    if (response['success']) {
      return response['result'];
    } else {
      throw Exception('Failed to convert currency');
    }
  }

  Future<Map<String, dynamic>> getCurrencies() async {
    try {
      final response = await fetch(
        endpoint: 'exchangerates_data/symbols',
      );

      // log(response.toString());
      final result = CurrencySymbolsResponse.fromJson(response);

      if (result.success) {
        return result.symbols;
      } else {
        throw Exception('Failed to load currencies');
      }
    } on Exception catch (e) {
      log(e.toString());
    }

    // Add a return statement here
    return {}; // or return an appropriate default value
  }
}
