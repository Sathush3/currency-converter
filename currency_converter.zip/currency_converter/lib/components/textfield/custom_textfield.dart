import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController controller;
  final String? labelText;
  final String? hintText;
  final double? width;
  final double? height;
  final Function()? onTap;
  final Function(String)? onChanged;
  final String? Function(String?)? validator;
  final bool? isEnabled;
  final String? errorText;
  final TextInputType keyboardType;
  final FocusNode focusNode;
  final Color? borderColor;
  final Widget? trailingIcon;
  final bool? readOnly;
  final int? maxLines;

  const CustomTextField({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.keyboardType,
    this.labelText,
    this.hintText,
    this.width,
    this.height,
    this.onTap,
    this.onChanged,
    this.validator,
    this.isEnabled,
    this.errorText,
    this.borderColor,
    this.trailingIcon,
    this.readOnly,
    this.maxLines,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width ?? 100.w,
      child: TextFormField(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        enabled: isEnabled ?? true,
        focusNode: focusNode,
        readOnly: readOnly ?? false,
        maxLines: maxLines ?? 1,
        scrollPadding: EdgeInsets.zero,
        textAlignVertical: TextAlignVertical.center,
        controller: controller,
        cursorColor: Theme.of(context).colorScheme.primary,
        textCapitalization: TextCapitalization.none,
        style: TextStyle(
          fontSize: 16.sp,
          color: Colors.white,
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(
            fontSize: 16.sp,
            color: Colors.white,
          ),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          fillColor: readOnly ?? false
              ? Theme.of(context).disabledColor
              : const Color(0xFF262425).withOpacity(0.95),
          contentPadding: EdgeInsets.symmetric(
            horizontal: 2.w,
            vertical: 1.h,
          ),
          suffixIcon: trailingIcon != null
              ? Align(
                  widthFactor: 0.1,
                  alignment: Alignment.centerRight,
                  child: Container(
                    margin: EdgeInsets.symmetric(
                      horizontal: 2.w,
                    ),
                    child: trailingIcon,
                  ),
                )
              : null,
          labelText: labelText,
          labelStyle: TextStyle(
            fontSize: 16.sp,
            color: Colors.white,
          ),
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3.w),
            borderSide: BorderSide(
              width: 0.25.w,
              color: borderColor ?? Colors.transparent,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3.w),
            borderSide: BorderSide(
              width: 0.25.w,
              color: Colors.transparent,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3.w),
            borderSide: BorderSide(
              width: 0.25.w,
              color: borderColor ?? Theme.of(context).dividerColor,
            ),
          ),
        ),
        keyboardType: keyboardType,
        validator: validator ?? (value) => null,
        onTap: onTap,
        onFieldSubmitted: (value) {
          FocusScope.of(context).nearestScope.requestFocus();
        },
        onChanged: onChanged,
      ),
    );
  }
}
