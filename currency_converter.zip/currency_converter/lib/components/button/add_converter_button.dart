import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class AddConverterButton extends StatelessWidget {
  final VoidCallback onPressed;

  const AddConverterButton({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 1.h, horizontal: 4.w),
      child: TextButton.icon(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all(
            const Color(0xff30591b),
          ),
          padding: WidgetStateProperty.all(
            EdgeInsets.symmetric(
              horizontal: 4.w,
            ),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.w),
            ),
          ),
        ),
        icon: const Icon(
          Icons.add,
          color: Color(0xff779e5f),
        ),
        onPressed: onPressed,
        label: Text(
          'ADD CONVERTER',
          style: TextStyle(
            fontSize: 15.sp,
            fontWeight: FontWeight.w700,
            color: const Color(0xff779e5f),
          ),
        ),
      ),
    );
  }
}
