import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class CustomSnackBar {
  static failureSnackBar({
    required String message,
    required BuildContext context,
  }) {
    final snackBar = SnackBar(
      content: Text(
        message,
        style: TextStyle(
          fontSize: 15.sp,
          color: Theme.of(context).textTheme.bodyLarge!.color,
        ),
      ),
      backgroundColor: Theme.of(context).colorScheme.error,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  static floatToast({
    required String message,
    required BuildContext context,
    Function? onClosed,
  }) {
    final snackBar = SnackBar(
      content: Text(
        message,
        style: TextStyle(
          fontSize: 15.sp,
          color: Colors.black,
        ),
        textAlign: TextAlign.center,
      ),
      backgroundColor: Colors.white.withOpacity(0.8),
      duration: const Duration(seconds: 1),
      behavior: SnackBarBehavior.floating,
      margin: EdgeInsets.symmetric(
        horizontal: 4.w,
        vertical: 4.h,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.w),
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar).closed.then(
      (reason) {
        onClosed?.call();
      },
    );
  }
}
