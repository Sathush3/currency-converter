import 'dart:io';

import 'package:currency_converter/api/currency_service/http_currency_service.dart';
import 'package:currency_converter/services/database_service/sql_database_service.dart';
import 'package:currency_converter/services/http_service/http_client_service.dart';
import 'package:currency_converter/stores/currency_exchange_store/currency_store.dart';
import 'package:get_it/get_it.dart';

Future<void> getItInitialize() async {
  GetIt getIt = GetIt.instance;

  // Register http client
  getIt.registerSingleton<HttpClients>(
    HttpClients(
      urlsToSkip: [],
      defaultHeaders: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
      },
    ),
  );
  // Register Currency API Service
  getIt.registerSingleton<CurrencyApiService>(
    CurrencyApiService(),
  );
  // Register SqlDatabaseService
  getIt.registerSingleton<SqlDatabaseService>(SqlDatabaseService());

  // Register Currency Store
  getIt.registerSingleton<CurrencyStore>(CurrencyStore());

  await getIt.allReady();
}
