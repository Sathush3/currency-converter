import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart';

class HttpClients extends BaseClient {
  final List<String> urlsToSkip;
  final Map<String, String> _headers = {};

  final secureStorage = const FlutterSecureStorage();

  HttpClients({
    required this.urlsToSkip,
    Map<String, String> defaultHeaders = const {},
  }) {
    _headers.addAll(defaultHeaders);
  }

  Future<String?> getApiKey() async {
    final apiKey = dotenv.get('API_KEY');
    return apiKey;
  }

  bool _containsAnyInSkippableList(String url) {
    return urlsToSkip.any((element) => url.contains(element));
  }

  void addHeader(String key, String value) {
    _headers[key] = value;
  }

  @override
  Future<StreamedResponse> send(BaseRequest request) async {
    String? apiKey = await getApiKey();
    request.headers.addAll(_headers);

    if (apiKey != null) {
      if (!_containsAnyInSkippableList(request.url.toString())) {
        request.headers.putIfAbsent('apikey', () => apiKey);
      } else {
        return request.send();
      }
    } else {
      throw Exception('API_KEY_NOT_FOUND');
    }

    return request.send();
  }
}
