import 'dart:developer';
import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  Future<String> requestPermission(Permission permission) async {
    try {
      final PermissionStatus status = await permission.request();

      switch (status) {
        case PermissionStatus.granted:
          return 'Granted';
        case PermissionStatus.denied:
        case PermissionStatus.limited:
          return 'Denied';
        case PermissionStatus.permanentlyDenied:
          await openAppSettings();
          return 'PermanentlyDenied';
        default:
          return 'Error';
      }
    } catch (e) {
      log('Error requesting permission: $e', name: 'PermissionService');
      return 'Error';
    }
  }

  Future<bool> isPermissionGranted(Permission permission) async {
    try {
      final PermissionStatus status = await permission.status;
      return status.isGranted;
    } catch (e) {
      log('Error checking permission status: $e', name: 'PermissionService');
      return false;
    }
  }

  Future<bool> checkCompositePermissions(List<Permission> permissions) async {
    try {
      for (var permission in permissions) {
        if (!await isPermissionGranted(permission)) {
          log('Permission not granted: $permission', name: 'PermissionService');
          return false;
        }
      }
      return true;
    } catch (e) {
      log('Error checking composite permissions: $e',
          name: 'PermissionService');
      return false;
    }
  }
}
