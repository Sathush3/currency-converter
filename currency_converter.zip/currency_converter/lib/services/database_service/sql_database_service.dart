import 'dart:async';
import 'package:currency_converter/model/currency_card_model/currency_card_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class SqlDatabaseService {
  Future<Database> createDatabase(String databaseName) async {
    String path = join(await getDatabasesPath(), databaseName);

    Database database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        db.execute('''
        CREATE TABLE IF NOT EXISTS currency_cards (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          currencyCode TEXT, 
          currencyName TEXT,
          flagIcon TEXT
        )
      ''');
      },
    );
    return database;
  }

  Future<Database> getDatabase(String databaseName) async {
    String path = join(await getDatabasesPath(), databaseName);
    Database database = await openDatabase(path, version: 1);
    return database;
  }

  Future<void> insertData(Database database, CurrencyCardModel card) async {
    try {
      await database.insert(
        'currency_cards',
        {
          'currencyCode': card.currencyCode,
          'currencyName': card.currencyName,
          'flagIcon': card.flagIcon,
        },
      );
    } catch (e) {
      Exception(e);
    }
  }

  Future<List<CurrencyCardModel>> getCurrencyCards() async {
    Database database = await getDatabase('currency.db');
    final List<Map<String, dynamic>> maps =
        await database.query('currency_cards');
    return List.generate(maps.length, (i) {
      return CurrencyCardModel(
        id: maps[i]['id'],
        currencyCode: maps[i]['currencyCode'],
        currencyName: maps[i]['currencyName'],
        flagIcon: maps[i]['flagIcon'],
      );
    });
  }

  Future<void> deleteCurrencyCard(int id) async {
    Database database = await getDatabase('currency.db');
    await database.delete(
      'currency_cards',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> updateCurrencyCard(
      Database database, CurrencyCardModel card) async {
    await database.update(
      'currency_cards',
      {
        'currencyCode': card.currencyCode,
        'currencyName': card.currencyName,
        'flagIcon': card.flagIcon,
      },
      where: 'id = ?',
      whereArgs: [card.id],
    );
  }

  Future<void> deleteAllData() async {
    Database database = await getDatabase('currency.db');
    await database.delete('currency_cards');
  }

  Future<void> deleteDatabase() async {
    join(await getDatabasesPath(), 'currency.db');
    await deleteDatabase();
  }
}
