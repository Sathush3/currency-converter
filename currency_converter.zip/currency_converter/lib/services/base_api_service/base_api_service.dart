import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:developer';
import 'dart:math' as math;
import 'package:currency_converter/services/http_service/http_client_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart';
import 'package:get_it/get_it.dart';

abstract class BaseApiService {
  @protected
  String baseUrl;

  @protected
  String endPointUrl;

  @protected
  BaseClient client;

  @protected
  static Map<String, String> defaultHeaders = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
  };

  @protected
  Map<String, String> headers = {};

  @protected
  Duration timeoutDuration = const Duration(seconds: 20);

  @protected
  int maxRetries = 2;

  @protected
  Duration initialDelay = const Duration(seconds: 1);

  @protected
  double backoffFactor = 2.0;

  BaseApiService({
    required this.endPointUrl,
    String? baseUrl,
    Map<String, String>? customHeaders,
    BaseClient? client,
  })  : baseUrl = baseUrl ?? dotenv.get('API_BASE_URL', fallback: ''),
        headers = {
          ...?customHeaders,
          ...defaultHeaders,
        },
        client = client ?? GetIt.I<HttpClients>();

  void addHeaders(Map<String, String> newHeaders) {
    headers.addAll(newHeaders);
  }

  void removeHeader(String key) {
    headers.remove(key);
  }

  List<String> headerKeys() {
    return headers.keys.toList();
  }

  @protected
  String urlPathConstructor({List<String> paths = const []}) {
    paths.insert(0, endPointUrl);
    paths.insert(0, baseUrl);
    return paths.join('/');
  }

  @protected
  Uri uriConstructor({
    List<String> paths = const [],
    Map<String, String> queryParams = const {},
  }) {
    final baseUri = Uri.parse(baseUrl);
    final pathSegments = [endPointUrl, ...paths];
    final Uri uri = Uri(
      scheme: baseUri.scheme,
      host: baseUri.host,
      path: pathSegments.join('/'),
      queryParameters: queryParams.isNotEmpty ? queryParams : null,
    );

    log('URI: $uri');

    return uri;
  }

  @protected
  Future<Map<String, String>> urlParamConstructor({
    Map<String, dynamic>? filterSortObject,
    List<Map<String, String>>? additionalParams,
    List<String>? query,
  }) async {
    final queryParams = <String, String>{};

    filterSortObject?.entries.forEach(
      (entry) {
        if (entry.value != null) {
          queryParams[entry.key] = entry.value.toString();
        }
      },
    );

    if (additionalParams != null) {
      for (var element in additionalParams) {
        queryParams[element['key']!] = element['value']!;
      }
    }

    if (query != null) {
      queryParams['query'] = '{${query.join(',')}}';
    }

    return queryParams;
  }

  Future<Map<String, dynamic>> fetchAll({
    Map<String, dynamic>? filterSortObject,
    List<Map<String, String>>? additionalParams,
    List<String>? query,
  }) async {
    final queryParams = await urlParamConstructor(
      filterSortObject: filterSortObject,
      additionalParams: additionalParams,
      query: query,
    );

    return _makeRequest(
      () => client.get(
        uriConstructor(
          queryParams: queryParams,
        ),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> fetch({
    required String endpoint,
    Map<String, dynamic>? filterSortObject,
    List<Map<String, String>>? additionalParams,
    List<String>? query,
  }) async {
    final queryParams = await urlParamConstructor(
      filterSortObject: filterSortObject,
      additionalParams: additionalParams,
      query: query,
    );

    return _makeRequest(
      () => client.get(
        uriConstructor(
          paths: [endpoint],
          queryParams: queryParams,
        ),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> _makeRequest(
    Future<Response> Function() request,
  ) async {
    int retryCount = 0;

    while (retryCount < maxRetries) {
      try {
        Response response = await request().timeout(timeoutDuration);
        checkResponseForErrors(response);
        if (response.body.isEmpty) return {};
        Map<String, dynamic> decodedBody = jsonDecode(response.body);

        return decodedBody;
      } on TimeoutException catch (e) {
        retryCount++;
        log('Request timed out: $e');
      } on SocketException catch (e) {
        retryCount++;
        log('Socket Exception: $e');
      } catch (e) {
        rethrow;
      }
      retryCount++;

      // Adding an exponential backoff delay with jitter between retries to avoid overwhelming the server
      final jitter = math.Random().nextInt(1000);
      final delay = initialDelay * math.pow(backoffFactor, retryCount) +
          Duration(milliseconds: jitter);
      await Future.delayed(delay);
    }

    throw Exception('Request failed after $maxRetries retries');
  }

  @protected
  void checkResponseForErrors(Response response) {
    if (!(response.statusCode >= 200 && response.statusCode < 300)) {
      throw 'API Error. Status Code: ${response.statusCode}, '
          'Headers: ${response.headers}, Body: ${response.body}';
    }
  }
}
