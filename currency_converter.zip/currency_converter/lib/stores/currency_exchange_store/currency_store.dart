import 'package:currency_converter/model/currency_card_model/currency_card_model.dart';
import 'package:currency_converter/services/database_service/sql_database_service.dart';
import 'package:mobx/mobx.dart';
import 'package:sqflite/sqflite.dart';

part 'currency_store.g.dart';

class CurrencyStore = _CurrencyStore with _$CurrencyStore;

abstract class _CurrencyStore with Store {
  final SqlDatabaseService _sqlDatabaseService = SqlDatabaseService();

  @observable
  ObservableList<CurrencyCardModel> currencyCards =
      ObservableList<CurrencyCardModel>();

  late Database _database;

  @action
  Future<void> initDatabase() async {
    _database = await _sqlDatabaseService.createDatabase('currency.db');
    await loadCurrencyCards();
  }

  @action
  Future<void> loadCurrencyCards() async {
    currencyCards.clear();
    currencyCards.addAll(await _sqlDatabaseService.getCurrencyCards());
  }

  @action
  Future<void> addCurrencyCard(CurrencyCardModel card) async {
    await _sqlDatabaseService.insertData(_database, card);
    await loadCurrencyCards();
  }

  @action
  Future<void> updateCurrencyCard(CurrencyCardModel card) async {
    await _sqlDatabaseService.updateCurrencyCard(_database, card);
    await loadCurrencyCards();
  }

  @action
  Future<void> deleteCurrencyCard(int id) async {
    await _sqlDatabaseService.deleteCurrencyCard(id);
    await loadCurrencyCards();
  }

  @action
  Future<void> deleteAllData() async {
    await _sqlDatabaseService.deleteAllData();
    await loadCurrencyCards();
  }

  @action
  Future<void> deleteDatabase() async {
    await _sqlDatabaseService.deleteDatabase();
  }
}
