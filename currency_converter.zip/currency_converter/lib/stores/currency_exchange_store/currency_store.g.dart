// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'currency_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers

mixin _$CurrencyStore on _CurrencyStore, Store {
  late final _$currencyCardsAtom =
      Atom(name: '_CurrencyStore.currencyCards', context: context);

  @override
  ObservableList<CurrencyCardModel> get currencyCards {
    _$currencyCardsAtom.reportRead();
    return super.currencyCards;
  }

  @override
  set currencyCards(ObservableList<CurrencyCardModel> value) {
    _$currencyCardsAtom.reportWrite(value, super.currencyCards, () {
      super.currencyCards = value;
    });
  }

  late final _$initDatabaseAsyncAction =
      AsyncAction('_CurrencyStore.initDatabase', context: context);

  @override
  Future<void> initDatabase() {
    return _$initDatabaseAsyncAction.run(() => super.initDatabase());
  }

  late final _$loadCurrencyCardsAsyncAction =
      AsyncAction('_CurrencyStore.loadCurrencyCards', context: context);

  @override
  Future<void> loadCurrencyCards() {
    return _$loadCurrencyCardsAsyncAction.run(() => super.loadCurrencyCards());
  }

  late final _$addCurrencyCardAsyncAction =
      AsyncAction('_CurrencyStore.addCurrencyCard', context: context);

  @override
  Future<void> addCurrencyCard(CurrencyCardModel card) {
    return _$addCurrencyCardAsyncAction.run(() => super.addCurrencyCard(card));
  }

  late final _$updateCurrencyCardAsyncAction =
      AsyncAction('_CurrencyStore.updateCurrencyCard', context: context);

  @override
  Future<void> updateCurrencyCard(CurrencyCardModel card) {
    return _$updateCurrencyCardAsyncAction
        .run(() => super.updateCurrencyCard(card));
  }

  late final _$deleteCurrencyCardAsyncAction =
      AsyncAction('_CurrencyStore.deleteCurrencyCard', context: context);

  @override
  Future<void> deleteCurrencyCard(int id) {
    return _$deleteCurrencyCardAsyncAction
        .run(() => super.deleteCurrencyCard(id));
  }

  late final _$deleteAllDataAsyncAction =
      AsyncAction('_CurrencyStore.deleteAllData', context: context);

  @override
  Future<void> deleteAllData() {
    return _$deleteAllDataAsyncAction.run(() => super.deleteAllData());
  }

  late final _$deleteDatabaseAsyncAction =
      AsyncAction('_CurrencyStore.deleteDatabase', context: context);

  @override
  Future<void> deleteDatabase() {
    return _$deleteDatabaseAsyncAction.run(() => super.deleteDatabase());
  }

  @override
  String toString() {
    return '''
currencyCards: ${currencyCards}
    ''';
  }
}
